
Milestone 3 — Dataset Preprocessing

Synthetic dataset generated using Python Faker library.
All CSV files match the database schema for the Stray Animal Rescue Tracker project.

Included:
- 15 CSV files
- Structured synthetic data
- Pakistani-style names and locations
- FK-compatible records
