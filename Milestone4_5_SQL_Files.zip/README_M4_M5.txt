
Milestone 4:
- DDL CREATE TABLE statements included
- PK, FK and constraints added

Milestone 5:
- LOAD DATA INFILE statements added
- UPDATE and DELETE examples included
- Validation queries included
