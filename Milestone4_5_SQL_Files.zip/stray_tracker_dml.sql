
USE stray_tracker;

LOAD DATA INFILE 'species.csv'
INTO TABLE Species
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'animals.csv'
INTO TABLE Animals
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

UPDATE Animals
SET status='Adopted'
WHERE animal_id=7;

UPDATE Kennels
SET status='Available', animal_id=NULL
WHERE animal_id=7;

DELETE FROM Follow_Ups
WHERE outcome='No Response';
