
CREATE DATABASE IF NOT EXISTS stray_tracker;
USE stray_tracker;

CREATE TABLE Species (
    species_id INT AUTO_INCREMENT PRIMARY KEY,
    species_name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Breeds (
    breed_id INT AUTO_INCREMENT PRIMARY KEY,
    breed_name VARCHAR(100) NOT NULL,
    species_id INT NOT NULL,
    FOREIGN KEY (species_id) REFERENCES Species(species_id)
);

CREATE TABLE Animals (
    animal_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age VARCHAR(20),
    gender ENUM('Male','Female','Unknown') NOT NULL,
    microchip_no VARCHAR(50) UNIQUE,
    status VARCHAR(20) NOT NULL DEFAULT 'Rescued',
    species_id INT NOT NULL,
    breed_id INT,
    FOREIGN KEY (species_id) REFERENCES Species(species_id),
    FOREIGN KEY (breed_id) REFERENCES Breeds(breed_id)
);

CREATE TABLE Rescuers (
    rescuer_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(150) UNIQUE,
    area VARCHAR(100),
    organization VARCHAR(150)
);

CREATE TABLE Locations (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    street VARCHAR(200),
    area VARCHAR(100),
    city VARCHAR(100) DEFAULT 'Peshawar',
    latitude DECIMAL(9,6),
    longitude DECIMAL(9,6)
);

CREATE TABLE Stakeholders (
    stakeholder_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150),
    role VARCHAR(100),
    contact VARCHAR(20),
    email VARCHAR(150) UNIQUE,
    organization VARCHAR(150)
);

CREATE TABLE Incidents (
    incident_id INT AUTO_INCREMENT PRIMARY KEY,
    animal_id INT NOT NULL,
    rescuer_id INT NOT NULL,
    location_id INT NOT NULL,
    incident_date DATETIME NOT NULL,
    condition_on_arrival VARCHAR(20),
    remarks TEXT,
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id),
    FOREIGN KEY (rescuer_id) REFERENCES Rescuers(rescuer_id),
    FOREIGN KEY (location_id) REFERENCES Locations(location_id)
);

CREATE TABLE Incident_Stakeholders (
    incident_stakeholder_id INT AUTO_INCREMENT PRIMARY KEY,
    incident_id INT NOT NULL,
    stakeholder_id INT NOT NULL,
    FOREIGN KEY (incident_id) REFERENCES Incidents(incident_id),
    FOREIGN KEY (stakeholder_id) REFERENCES Stakeholders(stakeholder_id)
);

CREATE TABLE Shelters (
    shelter_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150),
    address TEXT,
    capacity INT,
    contact VARCHAR(20)
);

CREATE TABLE Kennels (
    kennel_id INT AUTO_INCREMENT PRIMARY KEY,
    shelter_id INT NOT NULL,
    animal_id INT,
    status VARCHAR(30),
    FOREIGN KEY (shelter_id) REFERENCES Shelters(shelter_id),
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id)
);

CREATE TABLE Health_Records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    animal_id INT NOT NULL,
    vet_id INT,
    examination_date DATE,
    diagnosis TEXT,
    treatment TEXT,
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id)
);

CREATE TABLE Vaccinations (
    vaccination_id INT AUTO_INCREMENT PRIMARY KEY,
    animal_id INT NOT NULL,
    record_id INT,
    vaccine_name VARCHAR(100),
    date_given DATE,
    next_due_date DATE,
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id),
    FOREIGN KEY (record_id) REFERENCES Health_Records(record_id)
);

CREATE TABLE Adopters (
    adopter_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150),
    phone VARCHAR(20),
    email VARCHAR(150) UNIQUE,
    address TEXT,
    id_verified TINYINT(1)
);

CREATE TABLE Adoptions (
    adoption_id INT AUTO_INCREMENT PRIMARY KEY,
    animal_id INT UNIQUE,
    adopter_id INT,
    adoption_date DATE,
    status VARCHAR(20),
    FOREIGN KEY (animal_id) REFERENCES Animals(animal_id),
    FOREIGN KEY (adopter_id) REFERENCES Adopters(adopter_id)
);

CREATE TABLE Follow_Ups (
    followup_id INT AUTO_INCREMENT PRIMARY KEY,
    adoption_id INT NOT NULL,
    followup_date DATE,
    outcome VARCHAR(50),
    notes TEXT,
    FOREIGN KEY (adoption_id) REFERENCES Adoptions(adoption_id)
);
