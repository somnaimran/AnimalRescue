
USE stray_tracker;

SELECT COUNT(*) AS animals_count FROM Animals;
SELECT COUNT(*) AS incidents_count FROM Incidents;
SELECT COUNT(*) AS adoptions_count FROM Adoptions;

SELECT animal_id
FROM Animals
WHERE name IS NULL;

SELECT incident_id
FROM Incidents
WHERE animal_id IS NULL;

SELECT i.incident_id
FROM Incidents i
LEFT JOIN Animals a
ON i.animal_id = a.animal_id
WHERE a.animal_id IS NULL;

SELECT f.followup_id
FROM Follow_Ups f
LEFT JOIN Adoptions ad
ON f.adoption_id = ad.adoption_id
WHERE ad.adoption_id IS NULL;
